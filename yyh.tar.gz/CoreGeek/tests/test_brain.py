import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from agent.brain import (  # noqa: E402
    TOWER_LOADOUT, _profitable_mines, _tower_sites, _wall_order, decide_full,
)
from agent.protocol import Pos, Turn  # noqa: E402


class BrainTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sample = ROOT.parents[2] / "docs" / "request.txt"
        cls.payload = json.loads(sample.read_text(encoding="utf-8"))

    def test_sample_response_has_all_top_level_fields(self):
        decision = decide_full(copy.deepcopy(self.payload))
        self.assertIsInstance(decision.commands, dict)
        self.assertIsInstance(decision.prompt, str)
        self.assertIsInstance(decision.execute_cmd, str)

    def test_left_base_prioritizes_right_upper_blue_zone(self):
        turn = Turn.load(copy.deepcopy(self.payload))
        self.assertEqual(
            (Pos(12, 25), Pos(11, 25), Pos(12, 24)), _tower_sites(turn),
        )
        self.assertEqual(("rocket", "railgun", "gatling"), TOWER_LOADOUT)

    def test_left_base_builds_right_wall_first_and_opens_rear(self):
        turn = Turn.load(copy.deepcopy(self.payload))
        walls = _wall_order(turn)
        self.assertEqual(
            (Pos(13, 26), Pos(13, 25), Pos(13, 24)), walls[:3],
        )
        self.assertNotIn(Pos(8, 22), walls)
        self.assertEqual(19, len(walls))

    def test_right_base_mirrors_defences_to_left_lower_side(self):
        payload = copy.deepcopy(self.payload)
        station = next(
            role for role in payload["teamOur"]["roles"]
            if role["roleType"] == "station"
        )
        station["pos"] = {"x": 30, "y": 8}
        turn = Turn.load(payload)
        self.assertEqual(
            (Pos(29, 6), Pos(30, 6), Pos(29, 7)), _tower_sites(turn),
        )
        self.assertEqual((Pos(28, 5), Pos(28, 6), Pos(28, 7)), _wall_order(turn)[:3])
        self.assertNotIn(Pos(33, 9), _wall_order(turn))

    def test_three_existing_towers_never_trigger_fourth_build(self):
        payload = copy.deepcopy(self.payload)
        payload["roundNo"] = 1
        payload["teamOur"]["goldNum"] = 100
        decision = decide_full(payload)
        builds = [
            command for command in decision.commands.values()
            if command.get("action") == "build" and command.get("name") != "wall"
        ]
        self.assertEqual([], builds)

    def test_level_two_base_spends_available_gold_on_weapon_upgrade(self):
        payload = copy.deepcopy(self.payload)
        payload["roundNo"] = 1
        payload["teamOur"]["goldNum"] = 100
        station = next(r for r in payload["teamOur"]["roles"] if r["roleType"] == "station")
        station["level"] = 2
        worker = next(r for r in payload["teamOur"]["roles"] if r["id"] == 10012)
        worker["pos"] = {"x": 24, "y": 20}
        decision = decide_full(payload)
        self.assertEqual(
            {"action": "buy", "name": "WeaponUpgradeVoucher1", "num": 1},
            decision.commands["10012"],
        )

    def test_weapon_voucher_is_applied_to_rocket_first(self):
        payload = copy.deepcopy(self.payload)
        payload["roundNo"] = 1
        station = next(r for r in payload["teamOur"]["roles"] if r["roleType"] == "station")
        station["level"] = 2
        rocket = next(r for r in payload["teamOur"]["roles"] if r["roleType"] == "rocket")
        worker = next(r for r in payload["teamOur"]["roles"] if r["id"] == 10012)
        worker["backpack"] = ["WeaponUpgradeVoucher1"]
        worker["pos"] = {"x": rocket["pos"]["x"] + 1, "y": rocket["pos"]["y"]}
        decision = decide_full(payload)
        self.assertEqual("use", decision.commands["10012"]["action"])
        self.assertEqual("WeaponUpgradeVoucher1", decision.commands["10012"]["name"])
        self.assertEqual([rocket["pos"]], decision.commands["10012"]["targetPos"])

    def test_nearby_iron_beats_distant_copper_by_turn_efficiency(self):
        payload = copy.deepcopy(self.payload)
        payload["mapInfo"]["zones"] = [
            {"neutralType": "vendor", "pos": {"x": 12, "y": 12}},
            {"neutralType": "iron", "pos": {"x": 11, "y": 15}},
            {"neutralType": "copper", "pos": {"x": 40, "y": 0}},
        ]
        turn = Turn.load(payload)
        worker = next(role for role in turn.workers() if role.unit_id == 10012)
        ranked = _profitable_mines(turn, worker, set())
        self.assertEqual((Pos(11, 15), "iron"), ranked[0])

    def test_low_health_worker_uses_medicine_before_work(self):
        payload = copy.deepcopy(self.payload)
        payload["roundNo"] = 1
        worker = next(r for r in payload["teamOur"]["roles"] if r["id"] == 10012)
        worker["health"] = 50
        worker["backpack"] = ["Medicine"]
        decision = decide_full(payload)
        self.assertEqual(
            {"action": "use", "name": "Medicine"}, decision.commands["10012"],
        )

    def test_damaged_adjacent_wall_uses_fixer(self):
        payload = copy.deepcopy(self.payload)
        payload["roundNo"] = 1
        wall = next(r for r in payload["teamOur"]["roles"] if r["roleType"] == "wall")
        wall["health"] = 300
        worker = next(r for r in payload["teamOur"]["roles"] if r["id"] == 10010)
        worker["pos"] = {"x": wall["pos"]["x"], "y": wall["pos"]["y"] + 1}
        worker["backpack"] = ["WallFixer"]
        decision = decide_full(payload)
        self.assertEqual("WallFixer", decision.commands["10010"]["name"])
        self.assertEqual([wall["pos"]], decision.commands["10010"]["targetPos"])

    def test_dense_near_base_wave_uses_bomb(self):
        payload = copy.deepcopy(self.payload)
        payload["roundNo"] = 71
        worker = next(r for r in payload["teamOur"]["roles"] if r["id"] == 10010)
        worker["backpack"] = ["Bomb"]
        payload["robot"]["roles"] = [
            {
                "id": 31000 + i, "pos": {"x": 14 + i % 2, "y": 24 + i // 2},
                "roleType": "middleRobot", "health": 60,
                "abnormalState": "", "targetTeam": "challenger",
            }
            for i in range(4)
        ]
        decision = decide_full(payload)
        self.assertEqual("Bomb", decision.commands["10010"]["name"])

    def test_active_task_requests_llm(self):
        payload = copy.deepcopy(self.payload)
        payload["phaseTask"] = "读取文件 /tmp/data 并回答 name 字段"
        payload["llmResp"] = ""
        decision = decide_full(payload)
        self.assertIn("严格JSON", decision.prompt)
        self.assertNotIn("10011", decision.commands)

    def test_task_is_accepted_early_when_time_allows(self):
        payload = copy.deepcopy(self.payload)
        payload["roundNo"] = 1
        pioneer = next(r for r in payload["teamOur"]["roles"] if r["roleType"] == "pioneer")
        pioneer["pos"] = {"x": 13, "y": 14}
        decision = decide_full(payload)
        self.assertEqual({"action": "acceptTask"}, decision.commands["10011"])

    def test_task_is_not_accepted_near_night(self):
        payload = copy.deepcopy(self.payload)
        payload["roundNo"] = 69
        pioneer = next(r for r in payload["teamOur"]["roles"] if r["roleType"] == "pioneer")
        pioneer["pos"] = {"x": 13, "y": 14}
        decision = decide_full(payload)
        self.assertNotEqual(
            "acceptTask", decision.commands.get("10011", {}).get("action"),
        )

    def test_llm_answer_is_submitted(self):
        payload = copy.deepcopy(self.payload)
        payload["phaseTask"] = "回答问题"
        payload["llmResp"] = '{"taskAnswer":"答案"}'
        decision = decide_full(payload)
        self.assertEqual(
            decision.commands["10011"],
            {"action": "submitAnswer", "taskAnswer": "答案"},
        )

    def test_upgraded_rocket_uses_exact_target_count(self):
        payload = copy.deepcopy(self.payload)
        payload["roundNo"] = 71
        rocket = next(r for r in payload["teamOur"]["roles"] if r["roleType"] == "rocket")
        rocket["level"] = 3
        rocket["cooldown"] = 0
        # Put all characters next to their paired towers and robots in range.
        characters = [r for r in payload["teamOur"]["roles"] if r["roleType"] in ("worker", "pioneer")]
        towers = sorted(
            [r for r in payload["teamOur"]["roles"] if r["roleType"] in ("gatling", "railgun", "rocket")],
            key=lambda r: (r["pos"]["x"], r["pos"]["y"]),
        )
        for character, tower in zip(sorted(characters, key=lambda r: r["id"]), towers):
            character["pos"] = {"x": tower["pos"]["x"] - 1, "y": tower["pos"]["y"]}
        decision = decide_full(payload)
        command = decision.commands[str(rocket["id"])]
        self.assertEqual(3, len(command["targetPos"]))


if __name__ == "__main__":
    unittest.main()
