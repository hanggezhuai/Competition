import json
from dataclasses import dataclass
from typing import Any

from .grid import next_step
from .protocol import (
    PIONEER,
    Pos,
    Turn,
    Unit,
    WALL,
    WALL_MATERIAL,
    WEAPON_BUILD_COST,
    attack_command,
    build_command,
    collect_command,
    distance,
    move_command,
    simple_command,
    station_footprint,
)

# Sites are ordered from most valuable/forward to least valuable.  Long-range
# weapons get the safest forward positions and the short-range gatling the last.
TOWER_LOADOUT = ("rocket", "railgun", "gatling")
STONE_BATCH = 6
ROBOT_SCORE = {
    "smallRobot": 1, "middleRobot": 2, "largeRobot": 4, "bossRobot": 10,
}
ROBOT_ATTACK = {
    "smallRobot": 5, "middleRobot": 10, "largeRobot": 20, "bossRobot": 40,
}
MAX_HEALTH = {
    "worker": (220,), "pioneer": (200,), "wall": (1000, 1500, 2000),
}
SUMMON_ORDERS = (
    "BossRobotSummonOrder", "LargeRobotSummonOrder",
    "MiddleRobotSummonOrder", "SmallRobotSummonOrder",
)
_NEIGHBOUR_STEPS = (
    (-1, -1), (-1, 0), (-1, 1),
    (0, -1), (0, 1),
    (1, -1), (1, 0), (1, 1),
)


@dataclass(frozen=True)
class Decision:
    commands: dict[str, dict[str, Any]]
    prompt: str = ""
    execute_cmd: str = ""


def decide_full(payload: dict[str, Any]) -> Decision:
    turn = Turn.load(payload)
    commands: dict[int, dict[str, Any]] = {}
    prompt, execute_cmd = _task_turn(turn, commands)
    _consumables(turn, commands)
    if turn.is_day:
        _day(turn, commands)
    else:
        _night(turn, commands)
    if turn.phase_task:
        for pioneer in turn.alive((PIONEER,)):
            action = commands.get(pioneer.unit_id, {}).get("action")
            if action not in ("submitAnswer", "use"):
                commands.pop(pioneer.unit_id, None)
    return Decision(
        {str(key): value for key, value in commands.items()}, prompt, execute_cmd,
    )


def _consumables(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    roles = turn.controllable()
    available_roles = tuple(
        role for role in roles if not (turn.phase_task and role.kind == PIONEER)
    )
    # 1. A dead character loses many future actions; an active-task pioneer dying
    # also ends the task. Heal before any economic or combat action.
    for role in roles:
        if role.unit_id in commands and commands[role.unit_id].get("action") == "submitAnswer":
            continue
        threshold = 0.50 if not turn.is_day else 0.35
        if _has_item(role, "Medicine") and role.health <= _max_health(role) * threshold:
            commands[role.unit_id] = simple_command("use", name="Medicine")

    # 2. Repair a badly damaged adjacent wall, especially during an active wave.
    for role in available_roles:
        if role.unit_id in commands:
            continue
        walls = [
            wall for wall in turn.walls()
            if distance(role.pos, wall.pos) <= 1
            and wall.health <= _max_health(wall) * (0.70 if not turn.is_day else 0.45)
        ]
        if _has_item(role, "WallFixer") and walls:
            wall = min(walls, key=lambda item: item.health / _max_health(item))
            commands[role.unit_id] = simple_command(
                "use", name="WallFixer", targetPos=[wall.pos.dump()],
            )

    if not turn.is_day:
        threatening = [
            robot for robot in turn.robots
            if robot.health > 0 and robot.target_team in ("", turn.team_type)
        ]
        bomb_target, bomb_value = _best_area_target(threatening, damage=100)
        if bomb_target is not None and bomb_value >= 220 and _near_base(turn, bomb_target, 8):
            user = next(
                (role for role in available_roles if role.unit_id not in commands and _has_item(role, "Bomb")),
                None,
            )
            if user is not None:
                commands[user.unit_id] = simple_command(
                    "use", name="Bomb", targetPos=[bomb_target.dump()],
                )

        dizzy_target, dizzy_value = _best_dizzy_target(threatening)
        if dizzy_target is not None and dizzy_value >= 45 and _near_base(turn, dizzy_target, 8):
            user = next(
                (role for role in available_roles if role.unit_id not in commands and _has_item(role, "DizzyWeapon")),
                None,
            )
            if user is not None:
                commands[user.unit_id] = simple_command(
                    "use", name="DizzyWeapon", targetPos=[dizzy_target.dump()],
                )

    # 3. Summon orders are offensive tempo items. Spend their action only after
    # our own defence is established; the sunk-cost item then pressures next night.
    defence_ready = (
        turn.station() is not None and turn.station().level >= 2
        and len(turn.weapons()) == 3
        and all(tower.level >= 2 for tower in turn.weapons())
    )
    if turn.is_day and defence_ready:
        for role in reversed(available_roles):
            if role.unit_id in commands:
                continue
            order = next((name for name in SUMMON_ORDERS if _has_item(role, name)), "")
            if order:
                commands[role.unit_id] = simple_command("use", name=order)


def _has_item(role: Unit, name: str) -> bool:
    return any(item.casefold() == name.casefold() for item in role.backpack)


def _max_health(unit: Unit) -> int:
    values = MAX_HEALTH.get(unit.kind)
    if not values:
        return max(1, unit.health)
    return values[min(max(unit.level, 1), len(values)) - 1]


def _near_base(turn: Turn, pos: Pos, radius: int) -> bool:
    station = turn.station()
    return station is not None and _footprint_distance(pos, turn.footprint(station)) <= radius


def _best_area_target(robots: list[Any], damage: int) -> tuple[Pos | None, int]:
    if not robots:
        return None, 0
    candidates = {
        Pos(robot.pos.x + dx, robot.pos.y + dy)
        for robot in robots for dx in (-1, 0, 1) for dy in (-1, 0, 1)
    }
    def value(center: Pos) -> int:
        return sum(
            min(damage, robot.health) + (30 * ROBOT_SCORE.get(robot.kind, 0) if robot.health <= damage else 0)
            for robot in robots if distance(center, robot.pos) <= 1
        )
    best = max(candidates, key=lambda center: (value(center), -center.x, -center.y))
    return best, value(best)


def _best_dizzy_target(robots: list[Any]) -> tuple[Pos | None, int]:
    active = [robot for robot in robots if robot.abnormal_state != "dizzy"]
    if not active:
        return None, 0
    candidates = {
        Pos(robot.pos.x + dx, robot.pos.y + dy)
        for robot in active for dx in (-1, 0, 1) for dy in (-1, 0, 1)
    }
    def value(center: Pos) -> int:
        return sum(
            ROBOT_ATTACK.get(robot.kind, 0)
            for robot in active if distance(center, robot.pos) <= 1
        )
    best = max(candidates, key=lambda center: (value(center), -center.x, -center.y))
    return best, value(best)


def decide(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Compatibility entry point used by simple harnesses."""
    return decide_full(payload).commands


def _task_turn(
    turn: Turn, commands: dict[int, dict[str, Any]],
) -> tuple[str, str]:
    pioneers = turn.alive((PIONEER,))
    if not pioneers:
        return "", ""
    pioneer = pioneers[0]
    if turn.phase_task:
        # Staying still is important: leaving the task point immediately fails it.
        if turn.llm_resp:
            answer, command = _parse_llm_response(turn.llm_resp)
            if command and not turn.last_cmd_result:
                return "", command
            if answer:
                commands[pioneer.unit_id] = simple_command(
                    "submitAnswer", taskAnswer=answer,
                )
                return "", ""
        prompt = _task_prompt(turn)
        return prompt, ""

    valid = sorted(
        (task for task in turn.tasks if task.valid and _task_fits_day(turn, pioneer, task)),
        key=lambda task: (
            -(task.score + task.gold * 0.5),
            distance(pioneer.pos, task.pos), task.timeout,
        ),
    )
    if not valid or not turn.is_day:
        return "", ""
    target = valid[0].pos
    if distance(pioneer.pos, target) <= 1:
        commands[pioneer.unit_id] = simple_command("acceptTask")
    else:
        step = next_step(turn, pioneer, _closest_stand(turn, pioneer, target))
        if step is not None:
            commands[pioneer.unit_id] = move_command(step)
    return "", ""


def _task_fits_day(turn: Turn, pioneer: Unit, task: Any) -> bool:
    """Only start work that can finish and still leave time to return to a gun."""
    elapsed = (turn.round_no - 1) % 130
    remaining_day = max(0, 70 - elapsed)
    travel_to_task = max(0, distance(pioneer.pos, task.pos) - 1)
    # LLM normally answers in two turns; sandbox tasks may need several probes.
    solve_budget = min(12, max(4, task.timeout // 3))
    towers = turn.weapons()
    if towers:
        return_to_defence = max(
            0, min(distance(task.pos, tower.pos) for tower in towers) - 1,
        )
    else:
        sites = _tower_sites(turn)
        return_to_defence = max(
            0, min((distance(task.pos, site) for site in sites), default=0) - 1,
        )
    # accept + LLM/sandbox/submit + return, with collision/error slack.
    required = travel_to_task + 1 + solve_budget + return_to_defence + 3
    return remaining_day >= required


def _closest_stand(turn: Turn, role: Unit, target: Pos) -> Pos:
    cells = [p for p in _neighbours(target) if turn.land(p) and p not in turn.blocked(role)]
    return min(cells, key=lambda p: (distance(role.pos, p), p.x, p.y), default=role.pos)


def _task_prompt(turn: Turn) -> str:
    result = turn.last_cmd_result or "（尚未执行沙盒命令）"
    return (
        "你是竞赛答题代理。解决下面任务，优先快速得到尽可能多的正确字段。"
        "可使用离线沙盒。只输出严格JSON，二选一："
        '{"taskAnswer":"最终提交的完整答案"} 或 '
        '{"executeCmd":"下一条安全、15秒内完成的shell命令"}。'
        "不要输出Markdown。若已有命令结果，请据此继续或直接作答。\n"
        f"任务：\n{turn.phase_task}\n上次命令结果：\n{result}"
    )


def _parse_llm_response(raw: str) -> tuple[str, str]:
    text = raw.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
    try:
        value = json.loads(text)
    except (ValueError, TypeError):
        return (text, "")
    if not isinstance(value, dict):
        return (text, "")
    return (str(value.get("taskAnswer") or ""), str(value.get("executeCmd") or ""))


def _day(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    sites = _tower_sites(turn)
    order = _wall_order(turn)
    standing_towers = {unit.pos for unit in turn.weapons()}
    standing_walls = {unit.pos for unit in turn.walls()}
    occupied = turn.occupied_cells()
    tower_slots_left = max(0, 3 - len(standing_towers))
    towers_missing = [
        pos for pos in sites if pos not in standing_towers
    ][:tower_slots_left]
    walls_missing = [pos for pos in order if pos not in standing_walls]
    free_towers = [pos for pos in towers_missing if pos not in occupied]
    free_walls = [pos for pos in walls_missing if pos not in occupied]

    claimed: set[Pos] = set()
    workers = turn.workers()
    for index, role in enumerate(workers):
        if role.unit_id in commands:
            continue
        if index == len(workers) - 1 and _economy_worker(turn, role, claimed, commands):
            continue
        _worker_day(
            turn, role, sites, free_towers, free_walls, claimed, commands,
        )
    for role, tower in _tower_pairs(turn):
        if role.kind != PIONEER:
            continue
        if turn.phase_task:
            continue
        if role.unit_id in commands:
            continue
        if distance(role.pos, tower.pos) <= 1 and role.pos not in walls_missing:
            continue
        step = _step_toward(turn, role, tower.pos, claimed, inside_only=True)
        if step is not None:
            commands[role.unit_id] = move_command(step)


def _economy_worker(
    turn: Turn, role: Unit, claimed: set[Pos], commands: dict[int, dict[str, Any]],
) -> bool:
    station = turn.station()
    if station is None:
        return False
    # Never strand a purchased voucher in the backpack. Generic weapon vouchers
    # are applied to the highest-priority tower currently at the matching level.
    for level in (1, 2):
        station_voucher = f"StationUpgradeVoucher{level}"
        if station_voucher in role.backpack and station.level == level:
            return _use_upgrade(turn, role, station, station_voucher, claimed, commands)
        weapon_voucher = f"WeaponUpgradeVoucher{level}"
        if weapon_voucher in role.backpack:
            tower = _priority_tower(turn, level)
            if tower is not None:
                return _use_upgrade(turn, role, tower, weapon_voucher, claimed, commands)

    shops = turn.zone_positions("weaponShop")
    upgrade = _next_upgrade(turn)
    if upgrade is not None and turn.gold >= upgrade[1] and shops:
        voucher, _ = upgrade
        shop = min(shops, key=lambda p: distance(role.pos, p))
        if distance(role.pos, shop) <= 1:
            commands[role.unit_id] = simple_command("buy", name=voucher, num=1)
        else:
            step = _step_toward(turn, role, shop, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)
        return True

    # Sell valuable ore in batches, retaining stone for the defensive worker.
    counts = {name: role.backpack.count(name) for name in ("copper", "iron", "stone")}
    sell_name = next((name for name in ("copper", "iron", "stone") if counts[name] >= 4), "")
    vendors = turn.zone_positions("vendor")
    if sell_name and vendors:
        vendor = min(vendors, key=lambda p: distance(role.pos, p))
        if distance(role.pos, vendor) <= 1:
            commands[role.unit_id] = simple_command(
                "sell", name=sell_name, num=counts[sell_name],
            )
        else:
            step = _step_toward(turn, role, vendor, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)
        return True

    if role.backpack_full:
        return False
    mines = _profitable_mines(turn, role, claimed)
    for mine, _ in mines:
        if distance(role.pos, mine) <= 1:
            commands[role.unit_id] = collect_command(mine)
            claimed.add(mine)
            return True
        claimed.add(mine)
        step = _step_toward(turn, role, mine, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
            return True
    return False


def _profitable_mines(
    turn: Turn, role: Unit, claimed: set[Pos],
) -> list[tuple[Pos, str]]:
    """Rank mines by expected sale value per full travel/collection turn."""
    vendors = turn.zone_positions("vendor")
    inventory = {
        kind: role.backpack.count(kind) for kind in ("stone", "iron", "copper")
    }
    active_kind = max(inventory, key=inventory.get) if max(inventory.values()) else ""

    def rank(item: tuple[Pos, str]) -> tuple[float, int, int, int]:
        mine, kind = item
        price = turn.vendor_prices.get(kind, {"stone": 1, "iron": 3, "copper": 5}[kind])
        needed = max(1, 4 - inventory[kind])
        outbound = max(0, distance(role.pos, mine) - 1)
        to_vendor = (
            max(0, min(distance(mine, vendor) for vendor in vendors) - 1)
            if vendors else 0
        )
        turns = outbound + needed + to_vendor + 1
        continuity_bonus = 1.25 if kind == active_kind else 1.0
        value_per_turn = price * needed * continuity_bonus / max(1, turns)
        return (-value_per_turn, outbound, mine.x, mine.y)

    return sorted(
        (item for item in turn.mines() if item[0] not in claimed), key=rank,
    )


def _priority_tower(turn: Turn, level: int) -> Unit | None:
    for kind in ("rocket", "railgun", "gatling"):
        candidates = [tower for tower in turn.weapons() if tower.kind == kind and tower.level == level]
        if candidates:
            return candidates[0]
    return None


def _next_upgrade(turn: Turn) -> tuple[str, int] | None:
    station = turn.station()
    if station is None:
        return None
    if station.level == 1:
        return ("StationUpgradeVoucher1", 100)
    for kind in ("rocket", "railgun", "gatling"):
        if any(tower.kind == kind and tower.level == 1 for tower in turn.weapons()):
            return ("WeaponUpgradeVoucher1", 100)
    for kind in ("rocket", "railgun"):
        if any(tower.kind == kind and tower.level == 2 for tower in turn.weapons()):
            return ("WeaponUpgradeVoucher2", 150)
    if station.level == 2:
        return ("StationUpgradeVoucher2", 150)
    if any(tower.kind == "gatling" and tower.level == 2 for tower in turn.weapons()):
        return ("WeaponUpgradeVoucher2", 150)
    return None


def _use_upgrade(
    turn: Turn, role: Unit, building: Unit, voucher: str,
    claimed: set[Pos], commands: dict[int, dict[str, Any]],
) -> bool:
    if _footprint_distance(role.pos, turn.footprint(building)) <= 1:
        commands[role.unit_id] = simple_command(
            "use", name=voucher, targetPos=[building.pos.dump()],
        )
    else:
        step = _step_toward(turn, role, building.pos, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
    return True


def _worker_day(
    turn: Turn,
    role: Unit,
    sites: tuple[Pos, ...],
    towers_missing: list[Pos],
    walls_missing: list[Pos],
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> None:
    if towers_missing and turn.gold >= WEAPON_BUILD_COST:
        for index, site in enumerate(sites):
            if site in towers_missing and site not in claimed:
                _build_or_walk(
                    turn, role, site, TOWER_LOADOUT[index], claimed, commands,
                )
                return
    if not walls_missing:
        return

    stones = role.backpack.count(WALL_MATERIAL)
    mine = _adjacent_mine(turn, role)
    if mine is not None and stones < STONE_BATCH:
        commands[role.unit_id] = collect_command(mine)
        claimed.add(mine)
        return
    if stones:
        for site in walls_missing:
            if site not in claimed:
                _build_or_walk(turn, role, site, WALL, claimed, commands)
                return
        return
    _mine(turn, role, claimed, commands)


def _adjacent_mine(turn: Turn, role: Unit) -> Pos | None:
    mines = sorted(
        (
            mine for mine in turn.stone_mines()
            if role.pos != mine and distance(role.pos, mine) <= 1
        ),
        key=lambda pos: (distance(role.pos, pos), pos.x, pos.y),
    )
    return mines[0] if mines else None


def _night(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    claimed: set[Pos] = set()
    for role, tower in _tower_pairs(turn):
        if role.unit_id in commands:
            continue
        if distance(role.pos, tower.pos) <= 1:
            if tower.cooldown > 0:
                continue
            targets = _attack_targets(turn, tower)
            if targets:
                command = attack_command(role.unit_id, targets[0])
                command["targetPos"] = [target.dump() for target in targets]
                commands[tower.unit_id] = command
            continue
        step = _step_toward(turn, role, tower.pos, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)


def _tower_pairs(turn: Turn) -> tuple[tuple[Unit, Unit], ...]:
    return tuple(zip(turn.controllable(), turn.weapons()))


def _attack_target(turn: Turn, tower: Unit) -> Pos | None:
    targets = _attack_targets(turn, tower)
    return targets[0] if targets else None


def _attack_targets(turn: Turn, tower: Unit) -> list[Pos]:
    reach = tower.range_of_attack()
    targets = [
        robot for robot in turn.robots
        if robot.health > 0 and distance(tower.pos, robot.pos) <= reach
    ]
    targets.sort(
        key=lambda robot: (
            0 if robot.target_team in ("", turn.team_type) else 1,
            distance(robot.pos, turn.station().pos) if turn.station() else 99,
            -ROBOT_SCORE.get(robot.kind, 0), robot.health, robot.robot_id,
        ),
    )
    count = tower.level if tower.kind in ("gatling", "rocket") else 1
    # Duplicate the best legal target when there are fewer enemies than barrels;
    # the protocol requires exactly `level` target positions after an upgrade.
    if tower.kind == "gatling" and targets:
        # Repeating one point is always inside the legal 90-degree cone and
        # concentrates bullets instead of risking a rejected spread attack.
        result = [targets[0].pos] * count
    else:
        result = [robot.pos for robot in targets[:count]]
    while result and len(result) < count:
        result.append(result[0])
    return result


def _build_or_walk(
    turn: Turn,
    role: Unit,
    target: Pos,
    name: str,
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> None:
    claimed.add(target)
    if role.pos != target and distance(role.pos, target) <= 1:
        commands[role.unit_id] = build_command(target, name)
        return
    step = _step_toward(turn, role, target, claimed)
    if step is not None:
        commands[role.unit_id] = move_command(step)


def _mine(
    turn: Turn,
    role: Unit,
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> bool:
    if role.backpack_full:
        return False
    mines = sorted(
        (pos for pos in turn.stone_mines() if pos not in claimed),
        key=lambda pos: (distance(role.pos, pos), pos.x, pos.y),
    )
    for mine in mines:
        if role.pos != mine and distance(role.pos, mine) <= 1:
            commands[role.unit_id] = collect_command(mine)
            claimed.add(mine)
            return True
        claimed.add(mine)
        step = _step_toward(turn, role, mine, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
            return True
    return False


def _step_toward(
    turn: Turn,
    role: Unit,
    target: Pos,
    claimed: set[Pos],
    *,
    inside_only: bool = False,
) -> Pos | None:
    for stand in _stand_cells(turn, role, target, claimed, inside_only):
        if stand == role.pos:
            return None
        step = next_step(turn, role, stand)
        if step is None or step in claimed:
            continue
        claimed.add(step)
        return step
    return None


def _stand_cells(
    turn: Turn,
    role: Unit,
    target: Pos,
    claimed: set[Pos],
    inside_only: bool = False,
) -> list[Pos]:
    station = turn.station()
    footprint = station_footprint(station.pos) if station else ()
    blocked = turn.blocked(role)
    cells = [
        pos for pos in _neighbours(target)
        if turn.land(pos)
        and pos not in blocked
        and (pos == role.pos or pos not in claimed)
        and (
            not inside_only
            or _footprint_distance(pos, footprint) <= 1
        )
    ]
    cells.sort(key=lambda pos: (
        distance(role.pos, pos), _footprint_distance(pos, footprint), pos.x, pos.y,
    ))
    return cells


def _tower_sites(turn: Turn) -> tuple[Pos, ...]:
    station = turn.station()
    if station is None:
        return ()
    footprint = station_footprint(station.pos)
    xs = [pos.x for pos in footprint]
    ys = [pos.y for pos in footprint]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    # Robots approach the upper-left base from the right, and the lower-right
    # base from the left. Put the rocket and railgun at the forward corner/edge.
    # Every position remains on the legal blue ring.
    base_on_left = (xmin + xmax) < turn.width - 1
    if base_on_left:
        preferred = (
            Pos(xmax + 1, ymax + 1), Pos(xmax, ymax + 1),
            Pos(xmax + 1, ymax),
        )
    else:
        preferred = (
            Pos(xmin - 1, ymin - 1), Pos(xmin, ymin - 1),
            Pos(xmin - 1, ymin),
        )
    return tuple(pos for pos in preferred if turn.land(pos))


def _wall_order(turn: Turn) -> tuple[Pos, ...]:
    station = turn.station()
    if station is None:
        return ()
    footprint = station_footprint(station.pos)
    xs = [pos.x for pos in footprint]
    ys = [pos.y for pos in footprint]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    base_on_left = (xmin + xmax) < turn.width - 1
    if base_on_left:
        # Seal the robot-facing right wall first, then the top/bottom flanks.
        order = [
            *(Pos(xmax + 2, y) for y in range(ymax + 2, ymin - 3, -1)),
            *(Pos(x, ymax + 2) for x in range(xmax + 1, xmin - 3, -1)),
            *(Pos(x, ymin - 2) for x in range(xmax + 1, xmin - 3, -1)),
            *(Pos(xmin - 2, y) for y in range(ymin - 1, ymax + 2)),
        ]
        entrance = Pos(xmin - 2, ymin - 1)
    else:
        # Exact strategic mirror for a lower-right base attacked from the left.
        order = [
            *(Pos(xmin - 2, y) for y in range(ymin - 2, ymax + 3)),
            *(Pos(x, ymin - 2) for x in range(xmin - 1, xmax + 3)),
            *(Pos(x, ymax + 2) for x in range(xmin - 1, xmax + 3)),
            *(Pos(xmax + 2, y) for y in range(ymax + 1, ymin - 2, -1)),
        ]
        entrance = Pos(xmax + 2, ymax + 1)
    return tuple(
        pos for pos in order if pos != entrance and turn.land(pos)
    )


def _cells_at_distance(station_pos: Pos, radius: int) -> tuple[Pos, ...]:
    footprint = station_footprint(station_pos)
    xs = [pos.x for pos in footprint]
    ys = [pos.y for pos in footprint]
    cells = []
    for x in range(min(xs) - radius, max(xs) + radius + 1):
        for y in range(min(ys) - radius, max(ys) + radius + 1):
            pos = Pos(x, y)
            if pos in footprint:
                continue
            if _footprint_distance(pos, footprint) == radius:
                cells.append(pos)
    return tuple(cells)


def _footprint_distance(pos: Pos, footprint: tuple[Pos, ...]) -> int:
    if not footprint:
        return 0
    return min(distance(pos, cell) for cell in footprint)


def _neighbours(pos: Pos) -> tuple[Pos, ...]:
    return tuple(
        Pos(pos.x + dx, pos.y + dy) for dx, dy in _NEIGHBOUR_STEPS
    )
