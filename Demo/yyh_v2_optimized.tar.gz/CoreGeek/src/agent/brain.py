import json
from dataclasses import dataclass
from typing import Any

from .grid import next_step
from .protocol import (
    LAND,
    PIONEER,
    Pos,
    Turn,
    Unit,
    WALL,
    WALL_MATERIAL,
    WEAPON_BUILD_COST,
    attack_command,
    build_command,
    collect_command,
    distance,
    move_command,
    simple_command,
    station_footprint,
)

# AOE focus for the early game: two forward rockets splash the incoming wave;
# a gatling at the inner-corner slot (the blue-ring cell closest to the base)
# keeps continuous no-cooldown close-range fire every round, covering the base
# perimeter and the wall gaps once the wave breaks through. The ring slot
# mapping in _worker_day assigns kinds by site index, so the first two built
# towers are rockets and the third is the gatling.
# The enemy-facing yellow wall sits directly in front of the blue weapon ring.
# Rockets are explicitly immune to path blocking; direct guns risk shooting
# into our own wall. Coordinated targeting below prevents rocket burst overkill.
TOWER_LOADOUT = ("rocket", "rocket", "rocket")
STONE_BATCH = 6
ORE_BATCH = 10
ROBOT_SCORE = {
    "smallRobot": 1, "middleRobot": 2, "largeRobot": 4, "bossRobot": 10,
}
ROBOT_ATTACK = {
    "smallRobot": 5, "middleRobot": 10, "largeRobot": 20, "bossRobot": 40,
}
MAX_HEALTH = {
    "worker": (220,), "pioneer": (200,), "wall": (1000, 1500, 2000),
}
SUMMON_ORDERS = (
    "BossRobotSummonOrder", "LargeRobotSummonOrder",
    "MiddleRobotSummonOrder", "SmallRobotSummonOrder",
)
_NEIGHBOUR_STEPS = (
    (-1, -1), (-1, 0), (-1, 1),
    (0, -1), (0, 1),
    (1, -1), (1, 0), (1, 1),
)


@dataclass(frozen=True)
class Decision:
    commands: dict[str, dict[str, Any]]
    prompt: str = ""
    execute_cmd: str = ""


# Build-site feedback loop. The judge reports per-role action legality in
# lastRoundRoleActionResults; a rejected build marks that cell as invalid and
# it is never retried. The server process lives across rounds, so module state
# naturally persists; it is reset whenever the station moves (new map/half).
_BUILD_BLACKLIST: set[Pos] = set()
_LAST_BUILD: dict[int, tuple[Pos, str]] = {}
_MAP_STATION: Pos | None = None
_ACTIVE_TASK_TEXT = ""
_TASK_LAST_COMMAND = ""
_TASK_LAST_ANSWER = ""


def decide_full(payload: dict[str, Any]) -> Decision:
    global _MAP_STATION, _ACTIVE_TASK_TEXT, _TASK_LAST_COMMAND, _TASK_LAST_ANSWER
    turn = Turn.load(payload)
    station = turn.station()
    station_pos = station.pos if station else None
    if station_pos != _MAP_STATION:
        _MAP_STATION = station_pos
        _BUILD_BLACKLIST.clear()
        _LAST_BUILD.clear()
        _ACTIVE_TASK_TEXT = ""
        _TASK_LAST_COMMAND = ""
        _TASK_LAST_ANSWER = ""
    for unit_id, (target, _) in list(_LAST_BUILD.items()):
        if unit_id in turn.last_results:
            if not turn.last_results[unit_id]:
                _BUILD_BLACKLIST.add(target)
            del _LAST_BUILD[unit_id]
    commands: dict[int, dict[str, Any]] = {}
    prompt, execute_cmd = _task_turn(turn, commands)
    _consumables(turn, commands)
    if turn.is_day:
        _day(turn, commands)
    else:
        _night(turn, commands)
    if turn.phase_task:
        for pioneer in turn.alive((PIONEER,)):
            action = commands.get(pioneer.unit_id, {}).get("action")
            if action not in ("submitAnswer", "use"):
                commands.pop(pioneer.unit_id, None)
    for unit_id, command in commands.items():
        if command.get("action") == "build":
            _LAST_BUILD[unit_id] = (Pos.load(command["targetPos"][0]), command["name"])
    return Decision(
        {str(key): value for key, value in commands.items()}, prompt, execute_cmd,
    )


def _consumables(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    roles = turn.controllable()
    available_roles = tuple(
        role for role in roles if not (turn.phase_task and role.kind == PIONEER)
    )
    # 1. A dead character loses many future actions; an active-task pioneer dying
    # also ends the task. Heal before any economic or combat action.
    for role in roles:
        if role.unit_id in commands and commands[role.unit_id].get("action") == "submitAnswer":
            continue
        threshold = 0.50 if not turn.is_day else 0.35
        if _has_item(role, "Medicine") and role.health <= _max_health(role) * threshold:
            commands[role.unit_id] = simple_command("use", name="Medicine")

    # 2. Repair a badly damaged adjacent wall, especially during an active wave.
    for role in available_roles:
        if role.unit_id in commands:
            continue
        walls = [
            wall for wall in turn.walls()
            if distance(role.pos, wall.pos) <= 1
            and wall.health <= _max_health(wall) * (0.70 if not turn.is_day else 0.45)
        ]
        if _has_item(role, "WallFixer") and walls:
            wall = min(walls, key=lambda item: item.health / _max_health(item))
            commands[role.unit_id] = simple_command(
                "use", name="WallFixer", targetPos=[wall.pos.dump()],
            )

    if not turn.is_day:
        threatening = [
            robot for robot in turn.robots
            if robot.health > 0 and robot.target_team in ("", turn.team_type)
        ]
        bomb_target, bomb_value = _best_area_target(threatening, damage=100)
        if bomb_target is not None and bomb_value >= 220 and _near_base(turn, bomb_target, 8):
            user = next(
                (role for role in available_roles if role.unit_id not in commands and _has_item(role, "Bomb")),
                None,
            )
            if user is not None:
                commands[user.unit_id] = simple_command(
                    "use", name="Bomb", targetPos=[bomb_target.dump()],
                )

        dizzy_target, dizzy_value = _best_dizzy_target(threatening)
        if dizzy_target is not None and dizzy_value >= 45 and _near_base(turn, dizzy_target, 8):
            user = next(
                (role for role in available_roles if role.unit_id not in commands and _has_item(role, "DizzyWeapon")),
                None,
            )
            if user is not None:
                commands[user.unit_id] = simple_command(
                    "use", name="DizzyWeapon", targetPos=[dizzy_target.dump()],
                )

    # 3. Summon orders are offensive tempo items. Spend their action only after
    # our own defence is established; the sunk-cost item then pressures next night.
    defence_ready = (
        turn.station() is not None and turn.station().level >= 2
        and len(turn.weapons()) == 3
        and all(tower.level >= 2 for tower in turn.weapons())
    )
    if turn.is_day and defence_ready:
        for role in reversed(available_roles):
            if role.unit_id in commands:
                continue
            order = next((name for name in SUMMON_ORDERS if _has_item(role, name)), "")
            if order:
                commands[role.unit_id] = simple_command("use", name=order)


def _has_item(role: Unit, name: str) -> bool:
    return any(item.casefold() == name.casefold() for item in role.backpack)


def _max_health(unit: Unit) -> int:
    values = MAX_HEALTH.get(unit.kind)
    if not values:
        return max(1, unit.health)
    return values[min(max(unit.level, 1), len(values)) - 1]


def _near_base(turn: Turn, pos: Pos, radius: int) -> bool:
    station = turn.station()
    return station is not None and _footprint_distance(pos, turn.footprint(station)) <= radius


def _best_area_target(robots: list[Any], damage: int) -> tuple[Pos | None, int]:
    if not robots:
        return None, 0
    candidates = {
        Pos(robot.pos.x + dx, robot.pos.y + dy)
        for robot in robots for dx in (-1, 0, 1) for dy in (-1, 0, 1)
    }
    def value(center: Pos) -> int:
        return sum(
            min(damage, robot.health) + (30 * ROBOT_SCORE.get(robot.kind, 0) if robot.health <= damage else 0)
            for robot in robots if distance(center, robot.pos) <= 1
        )
    best = max(candidates, key=lambda center: (value(center), -center.x, -center.y))
    return best, value(best)


def _best_dizzy_target(robots: list[Any]) -> tuple[Pos | None, int]:
    active = [robot for robot in robots if robot.abnormal_state != "dizzy"]
    if not active:
        return None, 0
    candidates = {
        Pos(robot.pos.x + dx, robot.pos.y + dy)
        for robot in active for dx in (-1, 0, 1) for dy in (-1, 0, 1)
    }
    def value(center: Pos) -> int:
        return sum(
            ROBOT_ATTACK.get(robot.kind, 0)
            for robot in active if distance(center, robot.pos) <= 1
        )
    best = max(candidates, key=lambda center: (value(center), -center.x, -center.y))
    return best, value(best)


def decide(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Compatibility entry point used by simple harnesses."""
    return decide_full(payload).commands


def _task_turn(
    turn: Turn, commands: dict[int, dict[str, Any]],
) -> tuple[str, str]:
    global _ACTIVE_TASK_TEXT, _TASK_LAST_COMMAND, _TASK_LAST_ANSWER
    pioneers = turn.alive((PIONEER,))
    if not pioneers:
        return "", ""
    pioneer = pioneers[0]
    if turn.phase_task:
        if turn.phase_task != _ACTIVE_TASK_TEXT:
            _ACTIVE_TASK_TEXT = turn.phase_task
            _TASK_LAST_COMMAND = ""
            _TASK_LAST_ANSWER = ""
        # Staying still is important: leaving the task point immediately fails it.
        if turn.llm_resp:
            answer, command = _parse_llm_response(turn.llm_resp)
            # The old implementation gated every later command on an empty
            # lastCmdResult, so only the first sandbox probe ever ran. Execute a
            # new command even while the previous result is present.
            if command and command != _TASK_LAST_COMMAND:
                _TASK_LAST_COMMAND = command
                return "", command
            if answer:
                rejected = any(code == 2 for code, _ in turn.errors)
                if rejected and answer == _TASK_LAST_ANSWER:
                    return _task_prompt(turn), ""
                _TASK_LAST_ANSWER = answer
                commands[pioneer.unit_id] = simple_command(
                    "submitAnswer", taskAnswer=answer,
                )
                return "", ""
        prompt = _task_prompt(turn)
        return prompt, ""

    _ACTIVE_TASK_TEXT = ""
    _TASK_LAST_COMMAND = ""
    _TASK_LAST_ANSWER = ""

    valid = sorted(
        (task for task in turn.tasks if task.valid and _task_fits_day(turn, pioneer, task)),
        key=lambda task: (
            -(task.score + task.gold * 0.5),
            distance(pioneer.pos, task.pos), task.timeout,
        ),
    )
    if not valid or not turn.is_day:
        return "", ""
    target = valid[0].pos
    if distance(pioneer.pos, target) <= 1:
        commands[pioneer.unit_id] = simple_command("acceptTask")
    else:
        step = next_step(turn, pioneer, _closest_stand(turn, pioneer, target))
        if step is not None:
            commands[pioneer.unit_id] = move_command(step)
    return "", ""


def _task_fits_day(turn: Turn, pioneer: Unit, task: Any) -> bool:
    """Only start work that can finish and still leave time to return to a gun."""
    elapsed = (turn.round_no - 1) % 130
    remaining_day = max(0, 70 - elapsed)
    travel_to_task = max(0, distance(pioneer.pos, task.pos) - 1)
    # LLM normally answers in two turns; sandbox tasks may need several probes.
    solve_budget = min(12, max(4, task.timeout // 3))
    towers = turn.weapons()
    if towers:
        return_to_defence = max(
            0, min(distance(task.pos, tower.pos) for tower in towers) - 1,
        )
    else:
        sites = _tower_sites(turn)
        return_to_defence = max(
            0, min((distance(task.pos, site) for site in sites), default=0) - 1,
        )
    # accept + LLM/sandbox/submit + return, with collision/error slack.
    required = travel_to_task + 1 + solve_budget + return_to_defence + 3
    return remaining_day >= required


def _closest_stand(turn: Turn, role: Unit, target: Pos) -> Pos:
    cells = [p for p in _neighbours(target) if turn.land(p) and p not in turn.blocked(role)]
    return min(cells, key=lambda p: (distance(role.pos, p), p.x, p.y), default=role.pos)


def _task_prompt(turn: Turn) -> str:
    result = turn.last_cmd_result or "（尚未执行沙盒命令）"
    feedback = "\n".join(
        f"错误码{code}: {description}" for code, description in turn.errors
    ) or "（无）"
    return (
        "你是竞赛答题代理。解决下面任务，优先快速得到尽可能多的正确字段。"
        "任务内容通常藏在沙盒文件里：若你尚不知道答案，必须先输出一条安全的"
        "探索命令（例如 ls 或 cat 任务文件）读取文件内容，再作答。"
        "禁止输出纯文本回复；不知道答案时请给出探索命令而不是文字。"
        "只输出严格JSON，二选一："
        '{"taskAnswer":"最终提交的完整答案"} 或 '
        '{"executeCmd":"下一条安全、15秒内完成的shell命令"}。'
        "不要输出Markdown。复杂任务可以逐回合给出多条不同的探索命令。"
        "若答案是对象或数组，请将它压缩编码为taskAnswer中的JSON字符串。"
        "若上次答案被判错，必须根据错误反馈修正，禁止原样重复。\n"
        f"任务：\n{turn.phase_task}\n上次命令结果：\n{result}\n"
        f"判题反馈：\n{feedback}\n上次提交答案：\n{_TASK_LAST_ANSWER or '（无）'}"
    )


def _parse_llm_response(raw: str) -> tuple[str, str]:
    text = raw.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
    try:
        value = json.loads(text)
    except (ValueError, TypeError):
        return ("", "")
    if not isinstance(value, dict):
        return ("", "")
    raw_answer = value.get("taskAnswer")
    if isinstance(raw_answer, (dict, list)):
        answer = json.dumps(raw_answer, ensure_ascii=False, separators=(",", ":"))
    else:
        answer = str(raw_answer or "").strip()
    command = str(value.get("executeCmd") or "").strip()
    # Never submit raw prose as an answer: a non-JSON reply is a protocol
    # violation and guarantees a rejected/wrong task submission.
    return (answer, command)


def _day(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    sites = _tower_sites(turn)
    order = _wall_order(turn)
    standing_towers = {unit.pos for unit in turn.weapons()}
    standing_walls = {unit.pos for unit in turn.walls()}
    occupied = turn.occupied_cells()
    tower_slots_left = max(0, 3 - len(standing_towers))
    towers_missing = [
        pos for pos in sites if pos not in standing_towers
    ][:tower_slots_left]
    walls_missing = [pos for pos in order if pos not in standing_walls]
    free_towers = [pos for pos in towers_missing if pos not in occupied]
    free_walls = [pos for pos in walls_missing if pos not in occupied]

    claimed: set[Pos] = {
        Pos.load(command["targetPos"][0])
        for command in commands.values() if command.get("action") == "move"
    }
    # Reserve travel time before dusk, rather than starting the return at night.
    remaining_day = 70 - (turn.round_no - 1) % 130
    returning: set[int] = set()
    for role in turn.workers():
        if role.unit_id not in commands:
            _deliver_upgrade(turn, role, claimed, commands)
    for role, tower in _tower_pairs(turn):
        if role.unit_id in commands or (turn.phase_task and role.kind == PIONEER):
            continue
        if remaining_day <= max(12, distance(role.pos, tower.pos) + 6):
            returning.add(role.unit_id)
            # Always enter the protected blue/green side before night. Standing
            # outside the yellow wall makes the controller the robot's first target.
            step = _step_toward(turn, role, tower.pos, claimed, inside_only=True)
            if step is not None:
                commands[role.unit_id] = move_command(step)
    workers = turn.workers()
    for index, role in enumerate(workers):
        if role.unit_id in commands or role.unit_id in returning:
            continue
        # Both workers rush the three weapons first. Starting economy before all
        # guns exist was leaving the first wave with only one/two active towers.
        if (not towers_missing
                and (index == len(workers) - 1 or not walls_missing)
                and _economy_worker(turn, role, claimed, commands)):
            continue
        _worker_day(
            turn, role, sites, free_towers, free_walls, claimed, commands,
        )
    for role, tower in _tower_pairs(turn):
        if role.kind != PIONEER:
            continue
        if turn.phase_task:
            continue
        if role.unit_id in commands or role.unit_id in returning:
            continue
        if (distance(role.pos, tower.pos) <= 1
                and role.pos not in walls_missing and role.pos not in towers_missing):
            continue
        step = _step_toward(turn, role, tower.pos, claimed, inside_only=True)
        if step is not None:
            commands[role.unit_id] = move_command(step)


def _deliver_upgrade(
    turn: Turn, role: Unit, claimed: set[Pos], commands: dict[int, dict[str, Any]],
) -> bool:
    station = turn.station()
    if station is None:
        return False
    # Never strand a purchased voucher in the backpack. Generic weapon vouchers
    # are applied to the highest-priority tower currently at the matching level.
    for level in (1, 2):
        station_voucher = f"StationUpgradeVoucher{level}"
        if station_voucher in role.backpack and station.level == level:
            return _use_upgrade(turn, role, station, station_voucher, claimed, commands)
        weapon_voucher = f"WeaponUpgradeVoucher{level}"
        if weapon_voucher in role.backpack:
            tower = _priority_tower(turn, level)
            if tower is not None:
                return _use_upgrade(turn, role, tower, weapon_voucher, claimed, commands)
    return False


def _economy_worker(
    turn: Turn, role: Unit, claimed: set[Pos], commands: dict[int, dict[str, Any]],
) -> bool:
    if turn.station() is None:
        return False
    if _deliver_upgrade(turn, role, claimed, commands):
        return True

    shops = turn.zone_positions("weaponShop")
    upgrade = _next_upgrade(turn)
    reserve = max(0, 3 - len(turn.weapons())) * WEAPON_BUILD_COST
    pending_voucher = any(
        item.startswith(("WeaponUpgradeVoucher", "StationUpgradeVoucher"))
        for unit in turn.controllable() for item in unit.backpack
    ) or any(command.get("action") == "buy" for command in commands.values())
    if (upgrade is not None and turn.gold - reserve >= upgrade[1] and shops
            and not pending_voucher and not role.backpack_full
            and _deliverable_today(turn, role, upgrade[2])):
        voucher = upgrade[0]
        shop = min(shops, key=lambda p: distance(role.pos, p))
        if distance(role.pos, shop) <= 1:
            commands[role.unit_id] = simple_command("buy", name=voucher, num=1)
        else:
            step = _step_toward(turn, role, shop, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)
        return True

    # The builder keeps stone until the front wall is finished.
    counts = {name: role.backpack.count(name) for name in ("copper", "iron", "stone")}
    vendors = turn.zone_positions("vendor")
    # Amortize trips over ten ores; sell earlier when it funds an upgrade.
    sell_name = next((name for name in ("copper", "iron", "stone") if counts[name] and (
        counts[name] >= ORE_BATCH or role.backpack_full
        or any(distance(role.pos, vendor) <= 1 for vendor in vendors)
        or (upgrade is not None and turn.gold - reserve
            + counts[name] * turn.vendor_prices.get(name, {"stone": 1, "iron": 3, "copper": 5}[name]) >= upgrade[1])
    )), "")
    if sell_name and vendors:
        vendor = min(vendors, key=lambda p: distance(role.pos, p))
        if distance(role.pos, vendor) <= 1:
            commands[role.unit_id] = simple_command(
                "sell", name=sell_name, num=counts[sell_name],
            )
        else:
            step = _step_toward(turn, role, vendor, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)
        return True

    if role.backpack_full:
        return False
    mines = _profitable_mines(turn, role, claimed)
    for mine, _ in mines:
        if distance(role.pos, mine) <= 1:
            commands[role.unit_id] = collect_command(mine)
            claimed.add(mine)
            return True
        claimed.add(mine)
        step = _step_toward(turn, role, mine, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
            return True
    return False


def _profitable_mines(
    turn: Turn, role: Unit, claimed: set[Pos],
) -> list[tuple[Pos, str]]:
    """Rank mines by expected sale value per full travel/collection turn."""
    vendors = turn.zone_positions("vendor")
    inventory = {
        kind: role.backpack.count(kind) for kind in ("stone", "iron", "copper")
    }
    active_kind = max(inventory, key=inventory.get) if max(inventory.values()) else ""

    def rank(item: tuple[Pos, str]) -> tuple[float, int, int, int]:
        mine, kind = item
        price = turn.vendor_prices.get(kind, {"stone": 1, "iron": 3, "copper": 5}[kind])
        needed = max(1, ORE_BATCH - inventory[kind])
        outbound = max(0, distance(role.pos, mine) - 1)
        to_vendor = (
            max(0, min(distance(mine, vendor) for vendor in vendors) - 1)
            if vendors else 0
        )
        turns = outbound + needed + to_vendor + 1
        continuity_bonus = 1.25 if kind == active_kind else 1.0
        value_per_turn = price * needed * continuity_bonus / max(1, turns)
        return (-value_per_turn, outbound, mine.x, mine.y)

    return sorted(
        (item for item in turn.mines() if item[0] not in claimed), key=rank,
    )


def _priority_tower(turn: Turn, level: int) -> Unit | None:
    for kind in ("rocket", "gatling", "railgun"):
        candidates = [tower for tower in turn.weapons() if tower.kind == kind and tower.level == level]
        if candidates:
            return candidates[0]
    return None


def _next_upgrade(turn: Turn) -> tuple[str, int, Unit] | None:
    """Highest-priority purchase: (voucher, price, target building).

    Returns the concrete target so the buyer can check same-day deliverability
    before spending gold; the target is derived from the same rocket-first
    priority order used when delivering a voucher already in the backpack.
    """
    station = turn.station()
    if station is None:
        return None
    for kind in ("rocket", "gatling", "railgun"):
        for tower in turn.weapons():
            if tower.kind == kind and tower.level == 1:
                return ("WeaponUpgradeVoucher1", 100, tower)
    if station.level == 1:
        return ("StationUpgradeVoucher1", 100, station)
    for kind in ("rocket", "gatling"):
        for tower in turn.weapons():
            if tower.kind == kind and tower.level == 2:
                return ("WeaponUpgradeVoucher2", 150, tower)
    if station.level == 2:
        return ("StationUpgradeVoucher2", 150, station)
    for tower in turn.weapons():
        if tower.kind == "railgun" and tower.level == 2:
            return ("WeaponUpgradeVoucher2", 150, tower)
    return None


def _deliverable_today(turn: Turn, role: Unit, target: Unit) -> bool:
    """Buying a voucher only pays off if it can be walked to the target and
    used before dusk; otherwise it strands in the backpack and is often lost
    to a night death (round-171 purchase never used, then the courier died).
    """
    if not turn.is_day:
        return False
    elapsed = (turn.round_no - 1) % 130
    remaining_day = max(0, 70 - elapsed)
    shops = turn.zone_positions("weaponShop")
    if not shops:
        return False
    shop = min(shops, key=lambda pos: distance(role.pos, pos))
    walk = max(0, distance(shop, target.pos) - 1)
    # buy turn + walk + use turn + collision/error slack.
    needed = 1 + walk + 1 + 2
    return remaining_day >= needed


def _use_upgrade(
    turn: Turn, role: Unit, building: Unit, voucher: str,
    claimed: set[Pos], commands: dict[int, dict[str, Any]],
) -> bool:
    if _footprint_distance(role.pos, turn.footprint(building)) <= 1:
        commands[role.unit_id] = simple_command(
            "use", name=voucher, targetPos=[building.pos.dump()],
        )
    else:
        step = _step_toward(turn, role, building.pos, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
    return True


def _worker_day(
    turn: Turn,
    role: Unit,
    sites: tuple[Pos, ...],
    towers_missing: list[Pos],
    walls_missing: list[Pos],
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> None:
    spent = sum(
        WEAPON_BUILD_COST for command in commands.values()
        if command.get("action") == "build" and command.get("name") != WALL
    )
    if towers_missing and turn.gold - spent >= WEAPON_BUILD_COST:
        # Map loadout kinds to the ring position, not the loop index: the k-th
        # still-missing site keeps its slot kind even when earlier slots are
        # already standing or blacklisted. With no affordable/valid tower cell
        # the worker falls through to walls instead of idling forever.
        for site in towers_missing:
            if site not in claimed:
                kind = TOWER_LOADOUT[sites.index(site)] if site in sites else TOWER_LOADOUT[0]
                _build_or_walk(turn, role, site, kind, claimed, commands)
                return
    if not walls_missing:
        return

    stones = role.backpack.count(WALL_MATERIAL)
    mine = _adjacent_mine(turn, role)
    # Collect one full trip's worth of stone (up to backpack capacity) before
    # returning to build: with distant mines, STONE_BATCH-sized trips left the
    # wall ring far from closed by night 2 and the builder kept dying mid-trip.
    capacity = role.capacity if role.capacity is not None else STONE_BATCH
    needed_stones = min(capacity, len(walls_missing))
    if mine is not None and stones < needed_stones and not role.backpack_full:
        commands[role.unit_id] = collect_command(mine)
        claimed.add(mine)
        return
    if stones:
        for site in walls_missing:
            if site not in claimed:
                _build_or_walk(turn, role, site, WALL, claimed, commands)
                return
        return
    _mine(turn, role, claimed, commands)


def _adjacent_mine(turn: Turn, role: Unit) -> Pos | None:
    mines = sorted(
        (
            mine for mine in turn.stone_mines()
            if role.pos != mine and distance(role.pos, mine) <= 1
        ),
        key=lambda pos: (distance(role.pos, pos), pos.x, pos.y),
    )
    return mines[0] if mines else None


def _night(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    claimed: set[Pos] = set()
    projected = {robot.robot_id: robot.health for robot in turn.robots}
    # Plan splash weapons first, then let direct guns finish survivors. Projected
    # HP prevents all three towers from wasting their simultaneous damage on one
    # already-doomed small robot.
    pairs = sorted(
        _tower_pairs(turn),
        key=lambda pair: ({"rocket": 0, "railgun": 1, "gatling": 2}.get(pair[1].kind, 3),
                          pair[1].unit_id),
    )
    for role, tower in pairs:
        if role.unit_id in commands:
            continue
        station = turn.station()
        protected = (
            station is not None
            and _footprint_distance(role.pos, turn.footprint(station)) <= 1
        )
        if distance(role.pos, tower.pos) <= 1 and not protected:
            step = _step_toward(
                turn, role, tower.pos, claimed, inside_only=True,
            )
            if step is not None:
                commands[role.unit_id] = move_command(step)
            continue
        if distance(role.pos, tower.pos) <= 1:
            if tower.cooldown > 0:
                continue
            targets = _attack_targets(turn, tower, projected)
            if targets:
                command = attack_command(role.unit_id, targets[0])
                command["targetPos"] = [target.dump() for target in targets]
                commands[tower.unit_id] = command
            continue
        step = _step_toward(turn, role, tower.pos, claimed, inside_only=True)
        if step is not None:
            commands[role.unit_id] = move_command(step)


def _tower_pairs(turn: Turn) -> tuple[tuple[Unit, Unit], ...]:
    controllable = turn.controllable()
    weapons = turn.weapons()
    if not controllable or not weapons:
        return ()
    station = turn.station()
    if station is None:
        return tuple(zip(controllable, weapons))
    footprint = turn.footprint(station)
    # The pioneer is the most valuable unit (it runs the phase tasks), so it
    # guards the tower closest to the station - the safest post - while the
    # tankier workers hold the forward guns closest to the incoming wave.
    ordered_weapons = sorted(
        weapons,
        key=lambda tower: (_footprint_distance(tower.pos, footprint),
                           tower.pos.x, tower.pos.y),
    )
    pioneers = [unit for unit in controllable if unit.kind == PIONEER]
    workers = [unit for unit in controllable if unit.kind != PIONEER]
    if pioneers:
        pairs = [(pioneers[0], ordered_weapons[0])]
        pairs.extend(zip(workers, ordered_weapons[1:]))
        return tuple(pairs)
    return tuple(zip(controllable, ordered_weapons))


def _attack_target(turn: Turn, tower: Unit) -> Pos | None:
    targets = _attack_targets(turn, tower)
    return targets[0] if targets else None


def _attack_targets(
    turn: Turn, tower: Unit, projected: dict[int, int] | None = None,
) -> list[Pos]:
    reach = tower.range_of_attack()
    health = projected if projected is not None else {
        robot.robot_id: robot.health for robot in turn.robots
    }
    ours = [
        robot for robot in turn.robots
        if robot.target_team in ("", turn.team_type)
    ]
    pool = ours if ours else list(turn.robots)
    targets = [
        robot for robot in pool
        if health.get(robot.robot_id, 0) > 0
        and distance(tower.pos, robot.pos) <= reach
    ]
    targets.sort(
        key=lambda robot: (
            0 if robot.target_team in ("", turn.team_type) else 1,
            _footprint_distance(robot.pos, turn.footprint(turn.station())) if turn.station() else 99,
            -ROBOT_SCORE.get(robot.kind, 0), robot.health, robot.robot_id,
        ),
    )
    count = tower.level if tower.kind in ("gatling", "rocket") else 1
    if tower.kind == "rocket" and targets:
        result = _plan_rockets(turn, tower, targets, health, count)
    elif tower.kind == "gatling" and targets:
        # Repeating one point is always inside the legal 90-degree cone and
        # concentrates bullets instead of risking a rejected spread attack.
        result = [targets[0].pos] * count
        health[targets[0].robot_id] = max(
            0, health[targets[0].robot_id] - 10 * count,
        )
    else:
        result = [robot.pos for robot in targets[:count]]
        if targets:
            health[targets[0].robot_id] = max(
                0, health[targets[0].robot_id] - 10 * max(1, tower.level),
            )
    while result and len(result) < count:
        result.append(result[0])
    return result


def _plan_rockets(
    turn: Turn, tower: Unit, robots: list[Any], health: dict[int, int], count: int,
) -> list[Pos]:
    result: list[Pos] = []
    for _ in range(count):
        alive = [robot for robot in robots if health.get(robot.robot_id, 0) > 0]
        if not alive:
            break
        candidates = {
            Pos(robot.pos.x + dx, robot.pos.y + dy)
            for robot in alive for dx in (-1, 0, 1) for dy in (-1, 0, 1)
            if 0 <= robot.pos.x + dx < turn.width
            and 0 <= robot.pos.y + dy < turn.height
            and distance(tower.pos, Pos(robot.pos.x + dx, robot.pos.y + dy))
            <= tower.range_of_attack()
        }

        def value(center: Pos) -> tuple[int, int]:
            damage_value = 0
            threat_value = 0
            for robot in alive:
                dist = distance(center, robot.pos)
                damage = 20 if dist == 0 else 10 if dist == 1 else 0
                dealt = min(damage, health[robot.robot_id])
                damage_value += dealt
                if dealt >= health[robot.robot_id]:
                    damage_value += 10 * ROBOT_SCORE.get(robot.kind, 0)
                if damage:
                    threat_value += ROBOT_ATTACK.get(robot.kind, 0)
            return damage_value, threat_value

        center = max(candidates, key=lambda pos: (value(pos), -pos.x, -pos.y))
        result.append(center)
        for robot in alive:
            dist = distance(center, robot.pos)
            damage = 20 if dist == 0 else 10 if dist == 1 else 0
            health[robot.robot_id] = max(0, health[robot.robot_id] - damage)
    return result


def _build_or_walk(
    turn: Turn,
    role: Unit,
    target: Pos,
    name: str,
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> None:
    claimed.add(target)
    if role.pos != target and distance(role.pos, target) <= 1:
        commands[role.unit_id] = build_command(target, name)
        return
    step = _step_toward(turn, role, target, claimed)
    if step is not None:
        commands[role.unit_id] = move_command(step)


def _mine(
    turn: Turn,
    role: Unit,
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> bool:
    if role.backpack_full:
        return False
    mines = sorted(
        (pos for pos in turn.stone_mines() if pos not in claimed),
        key=lambda pos: (distance(role.pos, pos), pos.x, pos.y),
    )
    for mine in mines:
        if role.pos != mine and distance(role.pos, mine) <= 1:
            commands[role.unit_id] = collect_command(mine)
            claimed.add(mine)
            return True
        claimed.add(mine)
        step = _step_toward(turn, role, mine, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
            return True
    return False


def _step_toward(
    turn: Turn,
    role: Unit,
    target: Pos,
    claimed: set[Pos],
    *,
    inside_only: bool = False,
) -> Pos | None:
    for stand in _stand_cells(turn, role, target, claimed, inside_only):
        if stand == role.pos:
            return None
        step = next_step(turn, role, stand)
        if step is None or step in claimed:
            continue
        claimed.add(step)
        return step
    return None


def _stand_cells(
    turn: Turn,
    role: Unit,
    target: Pos,
    claimed: set[Pos],
    inside_only: bool = False,
) -> list[Pos]:
    station = turn.station()
    footprint = station_footprint(station.pos) if station else ()
    blocked = turn.blocked(role)
    cells = [
        pos for pos in _neighbours(target)
        if turn.land(pos)
        and pos not in blocked
        and (pos == role.pos or pos not in claimed)
        and (
            not inside_only
            or _footprint_distance(pos, footprint) <= 1
        )
    ]
    cells.sort(key=lambda pos: (
        distance(role.pos, pos), _footprint_distance(pos, footprint), pos.x, pos.y,
    ))
    return cells


def _blocked_grid(turn: Turn, extra: set[Pos] | frozenset[Pos] = frozenset()) -> bytearray:
    """Static movement blockers as a width*height bit grid: every non-land
    zone (mines, vendor, weapon shop, task points), the base footprint,
    standing towers/walls and enemy buildings. Roles and robots are transient
    and are handled at move time, so they are excluded here."""
    width, height = turn.width, turn.height
    grid = bytearray(width * height)

    def mark(pos: Pos) -> None:
        if 0 <= pos.x < width and 0 <= pos.y < height:
            grid[pos.y * width + pos.x] = 1

    for pos, kind in turn.zones.items():
        if kind != LAND:
            mark(pos)
    station = turn.station()
    if station is not None:
        for pos in station_footprint(station.pos):
            mark(pos)
    for unit in turn.weapons():
        mark(unit.pos)
    for unit in turn.walls():
        mark(unit.pos)
    for pos in turn.enemy_buildings():
        mark(pos)
    for pos in extra:
        mark(pos)
    return grid


def _outside_reachable_set(
    turn: Turn, extra_blocked: set[Pos] | frozenset[Pos] = frozenset(),
    static_grid: bytearray | None = None,
) -> bytearray:
    """Bit grid of cells reachable from beyond the yellow wall ring (seeds at
    footprint distance >= 3), flooded over land with 8-connectivity while
    treating static blockers as walls. This is the guard that guarantees every
    weapon stays reachable from the outside once the wall ring stands: a tower
    is usable at night only if a role can stand next to it."""
    station = turn.station()
    if station is None:
        return bytearray(0)
    width, height = turn.width, turn.height
    if static_grid is None:
        static_grid = _blocked_grid(turn)
    blocked = bytearray(static_grid)
    for pos in extra_blocked:
        if 0 <= pos.x < width and 0 <= pos.y < height:
            blocked[pos.y * width + pos.x] = 1
    footprint = station_footprint(station.pos)
    x0 = min(pos.x for pos in footprint)
    x1 = max(pos.x for pos in footprint)
    y0 = min(pos.y for pos in footprint)
    y1 = max(pos.y for pos in footprint)
    seen = bytearray(width * height)
    frontier: list[tuple[int, int]] = []
    for y in range(height):
        for x in range(width):
            idx = y * width + x
            if not blocked[idx] and max(0, x0 - x, x - x1, y0 - y, y - y1) >= 3:
                seen[idx] = 1
                frontier.append((x, y))
    while frontier:
        x, y = frontier.pop()
        for dx, dy in _NEIGHBOUR_STEPS:
            nx, ny = x + dx, y + dy
            if not 0 <= nx < width or not 0 <= ny < height:
                continue
            idx = ny * width + nx
            if seen[idx] or blocked[idx]:
                continue
            seen[idx] = 1
            frontier.append((nx, ny))
    return seen


def _tower_reachable(seen: bytearray, turn: Turn, pos: Pos) -> bool:
    width = turn.width
    return any(
        0 <= step.x < width and 0 <= step.y < turn.height
        and seen[step.y * width + step.x]
        for step in _neighbours(pos)
    )


def _tower_sites(turn: Turn) -> tuple[Pos, ...]:
    station = turn.station()
    if station is None:
        return ()
    footprint = station_footprint(station.pos)
    xs = [pos.x for pos in footprint]
    ys = [pos.y for pos in footprint]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    # Prefer the mirrored two-forward-one-rear arc on the enemy side, then fall
    # back to every remaining blue-ring cell. The real map's buildable zone is
    # an unknown subset of the ring, so failed attempts blacklist cells and the
    # candidate list slides around the full ring until something sticks.
    base_on_left = (xmin + xmax) < turn.width - 1
    if base_on_left:
        preferred = (
            Pos(xmax + 1, ymax + 1), Pos(xmax + 1, ymin - 1),
            Pos(xmax, ymax + 1),
        )
    else:
        preferred = (
            Pos(xmin - 1, ymin - 1), Pos(xmin - 1, ymax + 1),
            Pos(xmin, ymin - 1),
        )
    rest = [pos for pos in _cells_at_distance(station.pos, 1) if pos not in preferred]
    rest.sort(key=lambda pos: (pos.x, pos.y))
    # Every blue-ring candidate must be reachable from the outside: a tower
    # whose neighbours are all blocked (base footprint, zones, walls, enemy
    # buildings) could never be manned at night, so it is skipped before gold
    # is wasted on it.
    reachable = _outside_reachable_set(turn)
    return tuple(
        pos for pos in (*preferred, *rest)
        if turn.land(pos) and pos not in _BUILD_BLACKLIST
        and _tower_reachable(reachable, turn, pos)
    )


def _wall_order(turn: Turn) -> tuple[Pos, ...]:
    station = turn.station()
    if station is None:
        return ()
    footprint = station_footprint(station.pos)
    xs = [pos.x for pos in footprint]
    ys = [pos.y for pos in footprint]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    # Wall build order: the enemy-facing column first (direct first contact),
    # then the top/bottom flank rows filled from the enemy side inward (the
    # gaps robots actually slip through to reach the base). The far rear
    # column is deliberately NOT built: a fully closed ring would seal our own
    # workers/pioneer out of the base at night (they must stand next to the
    # towers to fire), so the rear stays open as the permanent entrance.
    base_on_left = (xmin + xmax) < turn.width - 1
    if base_on_left:
        enemy_col = [Pos(xmax + 2, y) for y in range(ymax + 2, ymin - 3, -1)]
        top_row = [Pos(x, ymax + 2) for x in range(xmax + 1, xmin - 2, -1)]
        bottom_row = [Pos(x, ymin - 2) for x in range(xmax + 1, xmin - 2, -1)]
        rear_col = [Pos(xmin - 2, y) for y in range(ymin - 2, ymax + 3)]
    else:
        enemy_col = [Pos(xmin - 2, y) for y in range(ymin - 2, ymax + 3)]
        top_row = [Pos(x, ymax + 2) for x in range(xmin - 1, xmax + 2)]
        bottom_row = [Pos(x, ymin - 2) for x in range(xmin - 1, xmax + 2)]
        rear_col = [Pos(xmax + 2, y) for y in range(ymax + 2, ymin - 3, -1)]
    preferred = [*enemy_col, *top_row, *bottom_row]
    excluded = set(rear_col)
    rest = [
        pos for pos in _cells_at_distance(station.pos, 2)
        if pos not in preferred and pos not in excluded
    ]
    rest.sort(key=lambda pos: (pos.x, pos.y))
    candidates = [
        pos for pos in (*preferred, *rest)
        if turn.land(pos) and pos not in _BUILD_BLACKLIST
    ]
    # Never build a wall that seals a tower off from the outside: roles must be
    # able to walk in from the map edge and stand next to every gun at night.
    # The check simulates the ring being built in order, so the final cell that
    # would close the ring is skipped (the rear column is already excluded
    # above, keeping the permanent entrance). This also self-protects against
    # zones/mines sealing the entrance corridor on unusual maps.
    targets = {unit.pos for unit in turn.weapons()}
    targets.update(_tower_sites(turn))
    static_grid = _blocked_grid(turn)
    simulated: set[Pos] = set()
    order: list[Pos] = []
    for pos in candidates:
        reachable = _outside_reachable_set(turn, simulated | {pos}, static_grid)
        if not targets or all(
            _tower_reachable(reachable, turn, target) for target in targets
        ):
            simulated.add(pos)
            order.append(pos)
    return tuple(order)


def _cells_at_distance(station_pos: Pos, radius: int) -> tuple[Pos, ...]:
    footprint = station_footprint(station_pos)
    xs = [pos.x for pos in footprint]
    ys = [pos.y for pos in footprint]
    cells = []
    for x in range(min(xs) - radius, max(xs) + radius + 1):
        for y in range(min(ys) - radius, max(ys) + radius + 1):
            pos = Pos(x, y)
            if pos in footprint:
                continue
            if _footprint_distance(pos, footprint) == radius:
                cells.append(pos)
    return tuple(cells)


def _footprint_distance(pos: Pos, footprint: tuple[Pos, ...]) -> int:
    if not footprint:
        return 0
    return min(distance(pos, cell) for cell in footprint)


def _neighbours(pos: Pos) -> tuple[Pos, ...]:
    return tuple(
        Pos(pos.x + dx, pos.y + dy) for dx, dy in _NEIGHBOUR_STEPS
    )
