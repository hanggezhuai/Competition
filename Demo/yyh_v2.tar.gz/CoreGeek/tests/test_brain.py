"""Unit tests for the CoreGeek agent brain.

Runs with stdlib unittest (the server environment is stdlib-only):
    python -m unittest discover -s tests -v
from the CoreGeek package root (D:\\...\\CoreGeek\\CoreGeek).
"""

import json
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from agent import brain  # noqa: E402
from agent.protocol import (  # noqa: E402
    WALL,
    Pos,
    station_footprint,
)


def make_payload(
    round_no=1,
    gold=200,
    roles=None,
    zones=None,
    phase_task="",
    llm_resp="",
    last_cmd_result="",
    last_results=None,
    robots=None,
    tasks=None,
    vendor_prices=None,
):
    """Build a minimal but protocol-faithful request payload.

    Default layout (base on the left, like the real practice match):
    station 10013 at (10,24) -> footprint (10,24),(11,24),(10,23),(11,23).
    """
    default_roles = [
        {"id": 10013, "pos": {"x": 10, "y": 24}, "roleType": "station",
         "health": 1500, "level": 1, "backPackCapability": 0, "backpack": []},
        {"id": 10010, "pos": {"x": 5, "y": 23}, "roleType": "worker",
         "health": 220, "backPackCapability": 100, "backpack": []},
        {"id": 10012, "pos": {"x": 10, "y": 16}, "roleType": "worker",
         "health": 220, "backPackCapability": 100, "backpack": []},
        {"id": 10011, "pos": {"x": 10, "y": 12}, "roleType": "pioneer",
         "health": 200, "backPackCapability": 40, "backpack": []},
    ]
    default_zones = [
        {"neutralType": "challengerTaskPoint1", "pos": {"x": 14, "y": 14}},
        {"neutralType": "vendor", "pos": {"x": 20, "y": 16}},
        {"neutralType": "weaponShop", "pos": {"x": 25, "y": 20}},
        {"neutralType": "stone", "pos": {"x": 4, "y": 24}},
        {"neutralType": "iron", "pos": {"x": 25, "y": 10}},
        {"neutralType": "copper", "pos": {"x": 22, "y": 26}},
    ]
    default_tasks = [
        {"taskType": "自进化类1", "taskPosition": {"x": 14, "y": 14},
         "scoreReward": 50, "goldReward": 30, "timeoutRounds": 30,
         "isValid": True},
    ]
    return {
        "roundNo": round_no,
        "mapInfo": {
            "width": 41, "height": 32,
            "zones": zones if zones is not None else default_zones,
        },
        "teamOur": {
            "type": "challenger", "teamId": "6324", "goldNum": gold,
            "playerTasks": tasks if tasks is not None else default_tasks,
            "roles": roles if roles is not None else default_roles,
        },
        "teamEnemy": {"roles": []},
        "robot": {"roles": robots or []},
        "phaseTask": phase_task,
        "llmResp": llm_resp,
        "lastCmdResult": last_cmd_result,
        "lastRoundRoleActionResults": last_results or {},
        "vendorShopList": vendor_prices or [
            {"name": "stone", "price": 1},
            {"name": "iron", "price": 3},
            {"name": "copper", "price": 5},
        ],
        "weaponShopList": [
            {"name": "WeaponUpgradeVoucher1", "price": 100},
            {"name": "WeaponUpgradeVoucher2", "price": 150},
            {"name": "StationUpgradeVoucher1", "price": 100},
            {"name": "StationUpgradeVoucher2", "price": 150},
        ],
        "worldNews": {"officialNews": "今日无重大新闻", "folkLegends": ""},
        "errors": [],
    }


def role(unit_id, x, y, role_type, **extra):
    data = {
        "id": unit_id, "pos": {"x": x, "y": y}, "roleType": role_type,
        "health": extra.pop("health", 1000), "level": extra.pop("level", 1),
        "attackRange": extra.pop("attackRange", 0),
        "backPackCapability": extra.pop("backPackCapability", 0),
        "backpack": extra.pop("backpack", []),
    }
    data.update(extra)
    return data


def tower(unit_id, x, y, kind, level=1, health=1000, cooldown=0):
    return role(unit_id, x, y, kind, level=level, health=health,
                attackRange=0, cooldown=cooldown)


def builds(decision):
    return [
        command for command in decision.commands.values()
        if command.get("action") == "build"
    ]


class BrainBase(unittest.TestCase):
    def setUp(self):
        brain._BUILD_BLACKLIST.clear()
        brain._LAST_BUILD.clear()
        brain._MAP_STATION = None


class TestLoadout(BrainBase):
    def test_first_two_towers_are_rockets_then_gatling(self):
        """The ring slots map rocket/rocket/gatling: the first built tower is a
        rocket, the second a rocket, the third a gatling, all at blue-ring
        distance. Each round the builder is placed adjacent to the expected
        site so the build lands in that same round."""
        station = Pos(10, 24)
        footprint = station_footprint(station)
        # Preferred blue-ring sites for a left-side base: slot 0,1,2.
        xs = [p.x for p in footprint]
        ys = [p.y for p in footprint]
        preferred = (Pos(max(xs) + 1, max(ys) + 1),   # (12,25) slot 0
                     Pos(max(xs) + 1, min(ys) - 1),   # (12,22) slot 1
                     Pos(max(xs), max(ys) + 1))       # (11,25) slot 2
        builder_spots = (Pos(11, 26), Pos(13, 22), Pos(10, 25))

        kinds = []
        standing = []
        for slot, (expected, spot) in enumerate(
                zip(("rocket", "rocket", "gatling"), builder_spots)):
            roles = [
                role(10013, 10, 24, "station"),
                role(10010, spot.x, spot.y, "worker", backPackCapability=100),
                role(10012, 10, 16, "worker", backPackCapability=100),
                role(10011, 10, 12, "pioneer", backPackCapability=40),
            ]
            roles.extend(standing)
            decision = brain.decide_full(
                make_payload(round_no=1 + slot, gold=100, roles=roles))
            cmds = builds(decision)
            self.assertTrue(cmds, f"slot {slot}: expected a build")
            build = cmds[0]
            target = Pos.load(build["targetPos"][0])
            self.assertEqual(brain._footprint_distance(target, footprint), 1,
                             f"tower at {target} must be on the blue ring")
            self.assertEqual(build["name"], expected,
                             f"slot {slot} kind mismatch")
            kinds.append(build["name"])
            standing.append(tower(10030 + slot, target.x, target.y, expected))
        self.assertEqual(kinds, ["rocket", "rocket", "gatling"])
        self.assertEqual(len({(t["pos"]["x"], t["pos"]["y"])
                              for t in standing}), 3)

        # The third build must have been the inner-corner gatling site.
        self.assertEqual(Pos.load(builds(decision)[0]["targetPos"][0]),
                         preferred[2])

    def test_wall_builds_on_yellow_ring(self):
        """With all three towers standing, a stonemason builds the first wall
        at yellow-ring distance with name 'wall'."""
        station = Pos(10, 24)
        footprint = station_footprint(station)
        # Compute the three standing towers directly from the preference order.
        xs = [p.x for p in footprint]
        ys = [p.y for p in footprint]
        preferred = (Pos(max(xs) + 1, max(ys) + 1),
                     Pos(max(xs) + 1, min(ys) - 1),
                     Pos(max(xs), max(ys) + 1))
        roles = [
            role(10013, 10, 24, "station"),
            role(10010, 12, 26, "worker", backPackCapability=100,
                 backpack=["stone"] * 6),
            role(10012, 10, 16, "worker", backPackCapability=100),
            role(10011, 10, 12, "pioneer", backPackCapability=40),
            tower(10030, preferred[0].x, preferred[0].y, "rocket"),
            tower(10031, preferred[1].x, preferred[1].y, "rocket"),
            tower(10040, preferred[2].x, preferred[2].y, "railgun"),
        ]
        payload = make_payload(round_no=1, gold=0, roles=roles)
        decision = brain.decide_full(payload)
        wall_builds = [
            command for command in builds(decision)
            if command.get("name") == WALL
        ]
        self.assertTrue(wall_builds, "expected a wall build")
        target = Pos.load(wall_builds[0]["targetPos"][0])
        self.assertEqual(brain._footprint_distance(target, footprint), 2,
                         f"wall at {target} must be on the yellow ring")

    def test_wall_order_enemy_column_first(self):
        """The first wall built must sit on the enemy-facing column
        (x = xmax+2 for a left-side base), not the rear column - the flank
        gaps are what let robots slip through to the base."""
        station = Pos(10, 24)
        footprint = station_footprint(station)
        xs = [p.x for p in footprint]
        ys = [p.y for p in footprint]
        preferred = (Pos(max(xs) + 1, max(ys) + 1),
                     Pos(max(xs) + 1, min(ys) - 1),
                     Pos(max(xs), max(ys) + 1))
        roles = [
            role(10013, 10, 24, "station"),
            role(10010, 12, 26, "worker", backPackCapability=100,
                 backpack=["stone"] * 20),
            role(10012, 10, 16, "worker", backPackCapability=100),
            role(10011, 10, 12, "pioneer", backPackCapability=40),
            tower(10030, preferred[0].x, preferred[0].y, "rocket"),
            tower(10031, preferred[1].x, preferred[1].y, "rocket"),
            tower(10040, preferred[2].x, preferred[2].y, "gatling"),
        ]
        decision = brain.decide_full(make_payload(round_no=1, gold=0, roles=roles))
        wall_builds = [
            command for command in builds(decision)
            if command.get("name") == WALL
        ]
        self.assertTrue(wall_builds, "expected a wall build")
        target = Pos.load(wall_builds[0]["targetPos"][0])
        self.assertEqual(target.x, max(xs) + 2,
                         f"first wall {target} must be on the enemy column")

    def test_wall_order_keeps_rear_open(self):
        """The rear column (x = xmin-2 for a left-side base) must never appear
        in the wall order: a fully closed ring seals our own roles out of the
        base at night (they must stand next to the towers to fire), so the
        rear stays open as the permanent entrance. The order is exactly the
        enemy column (6) plus both flank rows (4 + 4) = 14 cells."""
        roles = [
            role(10013, 10, 24, "station"),
            role(10010, 12, 26, "worker", backPackCapability=100,
                 backpack=["stone"] * 20),
            role(10012, 10, 16, "worker", backPackCapability=100),
            role(10011, 10, 12, "pioneer", backPackCapability=40),
            tower(10030, 12, 25, "rocket"),
            tower(10031, 12, 22, "rocket"),
            tower(10040, 11, 25, "gatling"),
        ]
        turn = brain.Turn.load(make_payload(round_no=1, gold=0, roles=roles))
        order = brain._wall_order(turn)
        station = Pos(10, 24)
        footprint = station_footprint(station)
        xs = [p.x for p in footprint]
        rear_x = min(xs) - 2
        self.assertEqual(len(order), 14)
        self.assertTrue(all(pos.x != rear_x for pos in order),
                        f"rear column x={rear_x} must stay open")
        # Enemy-facing column comes first, then the flank rows spanning the
        # full width between the two columns (x = min-1 .. max+1).
        self.assertEqual(order[0].x, max(xs) + 2)
        self.assertEqual(
            {pos.x for pos in order[6:]},
            set(range(min(xs) - 1, max(xs) + 2)),
        )

    def test_builder_collects_full_batch_before_building(self):
        """A worker next to a stone mine keeps collecting until it holds one
        full trip's worth (min of backpack capacity and walls missing), so
        distant mines do not force dozens of slow round trips."""
        roles = [
            role(10013, 10, 24, "station"),
            role(10010, 5, 24, "worker", backPackCapability=100,
                 backpack=["stone"] * 2),
            role(10012, 10, 16, "worker", backPackCapability=100),
            role(10011, 10, 12, "pioneer", backPackCapability=40),
            tower(10030, 12, 25, "rocket"),
            tower(10031, 12, 22, "rocket"),
            tower(10040, 11, 25, "gatling"),
        ]
        decision = brain.decide_full(make_payload(round_no=1, gold=0, roles=roles))
        command = decision.commands.get("10010", {})
        self.assertEqual(command.get("action"), "collect")
        # The stone mine in the default zones sits at (4,24), next to (5,24).
        self.assertEqual(Pos.load(command["targetPos"][0]), Pos(4, 24))

    def test_tower_site_sealed_by_zones_is_excluded(self):
        """Every element blocks movement (mines, task points, shops, enemy
        buildings, our own walls/towers). A blue-ring candidate whose every
        neighbour is blocked could never be manned at night, so it must be
        dropped from the tower sites before gold is wasted on it."""
        station = Pos(10, 24)
        footprint = station_footprint(station)
        xs = [p.x for p in footprint]
        ys = [p.y for p in footprint]
        sealed = Pos(max(xs) + 1, max(ys) + 1)  # (12,25) preferred slot 0
        # Block all seven non-base neighbours of (12,25) (only (11,24) is a
        # base cell); zones stand in for any movement-blocking neutral unit
        # (mine / task point / vendor / shop).
        blocked_neighbours = [Pos(11, 25), Pos(11, 26), Pos(12, 24),
                              Pos(12, 26), Pos(13, 24), Pos(13, 25),
                              Pos(13, 26)]
        zones = [{"neutralType": "stone",
                  "pos": {"x": pos.x, "y": pos.y}}
                 for pos in blocked_neighbours]

        turn = brain.Turn.load(make_payload(round_no=1, gold=0, zones=zones))
        sites = brain._tower_sites(turn)
        self.assertNotIn(sealed, sites,
                         f"sealed site {sealed} must be excluded")
        self.assertIn(Pos(max(xs) + 1, min(ys) - 1), sites,
                      "the reachable slot stays available")

        # Control: without the blocking zones the same site is a normal choice.
        normal = brain.Turn.load(make_payload(round_no=1, gold=0))
        self.assertIn(sealed, brain._tower_sites(normal))

    def test_wall_order_skips_cell_that_would_seal(self):
        """Walls may never close off the last path to a tower. If the rear
        entrance column is itself blocked (here by zones standing in for a
        mine), the final ring cell that would seal the interior must be
        skipped, keeping one gap roles can walk through."""
        rear_col = [Pos(8, y) for y in range(21, 27)]  # x = xmin-2
        zones = [{"neutralType": "stone",
                  "pos": {"x": pos.x, "y": pos.y}}
                 for pos in rear_col]
        roles = [
            role(10013, 10, 24, "station"),
            role(10010, 12, 26, "worker", backPackCapability=100,
                 backpack=["stone"] * 20),
            role(10012, 10, 16, "worker", backPackCapability=100),
            role(10011, 10, 12, "pioneer", backPackCapability=40),
            tower(10030, 12, 25, "rocket"),
            tower(10031, 12, 22, "rocket"),
            tower(10040, 11, 25, "gatling"),
        ]
        turn = brain.Turn.load(
            make_payload(round_no=1, gold=0, roles=roles, zones=zones))
        order = brain._wall_order(turn)
        # 14 ring cells minus the one that would close the ring (bottom-row
        # end cell (9,21)); the enemy column and the rest stay as planned.
        self.assertEqual(len(order), 13)
        self.assertNotIn(Pos(9, 21), order,
                         "ring-closing cell must be skipped")
        self.assertIn(Pos(10, 21), order)
        self.assertEqual(order[0], Pos(13, 26))


class TestEnemyBuildingsBlock(BrainBase):
    def test_enemy_buildings_are_static_blockers(self):
        """Enemy station/towers/walls block our movement just like our own
        buildings, so they must appear in the reachability blockers; enemy
        roles are transient and stay out."""
        enemies = [
            role(9001, 16, 26, "station"),   # footprint (16,26),(17,26),(16,25),(17,25)
            role(9002, 16, 28, "rocket"),
            role(9003, 15, 27, "wall"),
            role(9004, 18, 18, "worker"),    # transient, not a building
        ]
        payload = make_payload(round_no=1, gold=0)
        payload["teamEnemy"] = {"roles": enemies}
        turn = brain.Turn.load(payload)
        buildings = set(turn.enemy_buildings())
        expected = {Pos(16, 26), Pos(17, 26), Pos(16, 25), Pos(17, 25),
                    Pos(16, 28), Pos(15, 27)}
        self.assertEqual(buildings, expected)
        self.assertNotIn(Pos(18, 18), buildings)
        grid = brain._blocked_grid(turn)
        width = turn.width
        for pos in buildings:
            self.assertEqual(grid[pos.y * width + pos.x], 1,
                             f"enemy building {pos} must block")
        self.assertEqual(grid[18 * width + 18], 0)


class TestBlacklistFeedback(BrainBase):
    def test_rejected_build_site_is_not_retried(self):
        # Round 1: builder adjacent to the first blue-ring site (12,25).
        roles_r1 = [role(10013, 10, 24, "station"),
                    role(10010, 11, 26, "worker", backPackCapability=100),
                    role(10012, 10, 16, "worker", backPackCapability=100),
                    role(10011, 10, 12, "pioneer", backPackCapability=40)]
        first = brain.decide_full(
            make_payload(round_no=1, gold=100, roles=roles_r1))
        first_build = builds(first)[0]
        rejected = Pos.load(first_build["targetPos"][0])
        self.assertEqual(rejected, Pos(12, 25))
        # The site lands in _LAST_BUILD after round 1 and only enters the
        # blacklist once the judge reports the build was rejected.
        self.assertNotIn(rejected, brain._BUILD_BLACKLIST)

        # Round 2: the rejection feedback arrives; the builder now stands
        # adjacent to the next site (12,22), which must be chosen instead.
        roles_r2 = [role(10013, 10, 24, "station"),
                    role(10010, 13, 22, "worker", backPackCapability=100),
                    role(10012, 10, 16, "worker", backPackCapability=100),
                    role(10011, 10, 12, "pioneer", backPackCapability=40)]
        second = brain.decide_full(make_payload(
            round_no=2, gold=100, roles=roles_r2,
            last_results={"10010": False},
        ))
        self.assertIn(rejected, brain._BUILD_BLACKLIST)
        second_builds = builds(second)
        self.assertTrue(second_builds)
        for command in second_builds:
            target = Pos.load(command["targetPos"][0])
            self.assertNotEqual(target, rejected,
                                "rejected site must be blacklisted")


class TestParseLlmResponse(BrainBase):
    def test_parse_llm_response(self):
        cases = [
            ('{"taskAnswer":"42"}', ("42", "")),
            ('{"executeCmd":"ls"}', ("", "ls")),
            ('{"taskAnswer":"x", "executeCmd":"cat f"}', ("x", "cat f")),
            ('```json\n{"taskAnswer":"x"}\n```', ("x", "")),
            ('请提供task_3_gamma.md的具体内容，以便我解答任务。', ("", "")),
            ("", ("", "")),
            ("[]", ("", "")),
            ('{"taskAnswer":""}', ("", "")),
            ('{"taskAnswer": 123}', ("123", "")),
        ]
        for raw, expected in cases:
            with self.subTest(raw=raw):
                self.assertEqual(brain._parse_llm_response(raw), expected)


class TestPhaseTask(BrainBase):
    def test_submit_answer_round(self):
        roles = [role(10013, 10, 24, "station"),
                 role(10011, 10, 12, "pioneer", backPackCapability=40)]
        payload = make_payload(
            round_no=10, gold=0, roles=roles, phase_task="回答 1+1=?",
            llm_resp='{"taskAnswer":"2"}',
        )
        decision = brain.decide_full(payload)
        command = decision.commands.get("10011", {})
        self.assertEqual(command.get("action"), "submitAnswer")
        self.assertEqual(command.get("taskAnswer"), "2")

    def test_garbage_llm_reply_is_never_submitted(self):
        roles = [role(10013, 10, 24, "station"),
                 role(10011, 10, 12, "pioneer", backPackCapability=40)]
        payload = make_payload(
            round_no=10, gold=0, roles=roles, phase_task="回答 1+1=?",
            llm_resp="我不确定，请告诉我任务文件在哪里。",
        )
        decision = brain.decide_full(payload)
        command = decision.commands.get("10011", {})
        self.assertNotEqual(command.get("action"), "submitAnswer")
        self.assertTrue(decision.prompt, "prompt must be re-issued")

    def test_execute_cmd_returned_when_no_result_yet(self):
        roles = [role(10013, 10, 24, "station"),
                 role(10011, 10, 12, "pioneer", backPackCapability=40)]
        payload = make_payload(
            round_no=10, gold=0, roles=roles, phase_task="回答 1+1=?",
            llm_resp='{"executeCmd":"ls"}',
        )
        decision = brain.decide_full(payload)
        self.assertEqual(decision.execute_cmd, "ls")
        self.assertNotIn("10011", decision.commands)


class TestUpgradePriority(BrainBase):
    def test_next_upgrade_prefers_rocket(self):
        roles = [role(10013, 10, 24, "station"),
                 tower(10030, 12, 25, "rocket", level=1),
                 tower(10031, 11, 25, "railgun", level=1)]
        payload = make_payload(round_no=1, gold=100, roles=roles)
        turn = brain.Turn.load(payload)
        upgrade = brain._next_upgrade(turn)
        self.assertEqual(upgrade[0], "WeaponUpgradeVoucher1")
        self.assertEqual(upgrade[1], 100)
        self.assertEqual(upgrade[2].kind, "rocket")

    def test_next_upgrade_falls_back_to_railgun(self):
        roles = [role(10013, 10, 24, "station"),
                 tower(10030, 11, 25, "railgun", level=1)]
        payload = make_payload(round_no=1, gold=100, roles=roles)
        turn = brain.Turn.load(payload)
        upgrade = brain._next_upgrade(turn)
        self.assertEqual(upgrade[0], "WeaponUpgradeVoucher1")
        self.assertEqual(upgrade[2].kind, "railgun")

    def test_next_upgrade_station_voucher(self):
        roles = [role(10013, 10, 24, "station", level=1),
                 tower(10030, 12, 25, "rocket", level=2),
                 tower(10031, 11, 25, "railgun", level=2)]
        payload = make_payload(round_no=1, gold=200, roles=roles)
        turn = brain.Turn.load(payload)
        upgrade = brain._next_upgrade(turn)
        self.assertEqual(upgrade[0], "StationUpgradeVoucher1")
        self.assertEqual(upgrade[2].kind, "station")


class TestVoucherBuyTiming(BrainBase):
    def _economy_payload(self, round_no, worker_pos, gold):
        roles = [role(10013, 10, 24, "station"),
                 role(10012, worker_pos[0], worker_pos[1], "worker",
                      backPackCapability=100),
                 tower(10030, 12, 25, "rocket", level=1)]
        return make_payload(round_no=round_no, gold=gold, roles=roles)

    def test_buys_when_deliverable_same_day(self):
        # Round 2: day with 69 remaining rounds; shop (25,20) -> tower (12,25)
        # needs 1+12+1+2 = 16 turns, well within the day.
        payload = self._economy_payload(2, (25, 20), 200)
        decision = brain.decide_full(payload)
        buys = [
            command for command in decision.commands.values()
            if command.get("action") == "buy"
        ]
        self.assertEqual(len(buys), 1)
        self.assertEqual(buys[0]["name"], "WeaponUpgradeVoucher1")

    def test_no_buy_at_night(self):
        payload = self._economy_payload(85, (25, 20), 200)
        decision = brain.decide_full(payload)
        self.assertFalse(any(
            command.get("action") == "buy"
            for command in decision.commands.values()
        ))

    def test_no_buy_when_day_too_short(self):
        # Round 68 -> remaining_day 3, far below the 16 turns needed.
        payload = self._economy_payload(68, (25, 20), 200)
        decision = brain.decide_full(payload)
        self.assertFalse(any(
            command.get("action") == "buy"
            for command in decision.commands.values()
        ))

    def test_voucher_delivery_uses_at_tower(self):
        """A voucher already in the backpack must be walked to the priority
        (rocket-first) tower and used once adjacent - the buy->walk->use chain
        that the practice match never completed."""
        roles = [
            role(10013, 10, 24, "station"),
            role(10012, 11, 26, "worker", backPackCapability=100,
                 backpack=["WeaponUpgradeVoucher1"]),
            tower(10030, 12, 25, "rocket", level=1),
            tower(10031, 11, 25, "railgun", level=1),
        ]
        decision = brain.decide_full(
            make_payload(round_no=2, gold=0, roles=roles))
        command = decision.commands.get("10012", {})
        self.assertEqual(command.get("action"), "use")
        self.assertEqual(command.get("name"), "WeaponUpgradeVoucher1")
        self.assertEqual(command.get("targetPos"), [{"x": 12, "y": 25}])


class TestDecideStructure(BrainBase):
    def test_decide_full_shape(self):
        decision = brain.decide_full(make_payload(round_no=1, gold=100))
        self.assertIsInstance(decision.commands, dict)
        self.assertTrue(all(isinstance(key, str) for key in decision.commands))
        self.assertIsInstance(decision.prompt, str)
        self.assertIsInstance(decision.execute_cmd, str)


class TestTowerPairs(BrainBase):
    def test_pioneer_guards_rear_tower(self):
        """The pioneer (the unit that runs phase tasks) must be paired with the
        tower closest to the station so it guards from the safest post, while
        the workers hold the forward guns."""
        roles = [
            role(10013, 10, 24, "station"),
            role(10010, 12, 26, "worker", backPackCapability=100),
            role(10012, 10, 16, "worker", backPackCapability=100),
            role(10011, 10, 12, "pioneer", backPackCapability=40),
            tower(10030, 12, 25, "rocket"),
            tower(10031, 12, 22, "rocket"),
            tower(10040, 11, 25, "gatling"),
        ]
        turn = brain.Turn.load(make_payload(round_no=100, gold=0, roles=roles))
        pairs = brain._tower_pairs(turn)
        by_role = {pair[0].unit_id: pair[1] for pair in pairs}
        pioneer_tower = by_role[10011]
        # Rear-most tower for the left-side base: (11,25) sits one cell from
        # the footprint corner, closer than the x=12 forward rockets.
        self.assertEqual(pioneer_tower.pos, Pos(11, 25))
        self.assertEqual(pioneer_tower.kind, "gatling")
        self.assertEqual({by_role[10010].pos, by_role[10012].pos},
                         {Pos(12, 25), Pos(12, 22)})


if __name__ == "__main__":
    unittest.main()
